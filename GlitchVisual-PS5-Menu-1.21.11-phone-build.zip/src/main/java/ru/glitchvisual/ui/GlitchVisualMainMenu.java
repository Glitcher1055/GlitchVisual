package ru.glitchvisual.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

import java.util.Random;

public final class GlitchVisualMainMenu extends Screen {
    private final Random random = new Random(483921L);
    private final Star[] stars = new Star[170];
    private long openedAt;

    public GlitchVisualMainMenu() {
        super(Text.literal("GlitchVisual"));
        for (int i = 0; i < stars.length; i++) {
            stars[i] = new Star(random.nextFloat(), random.nextFloat(),
                    0.4f + random.nextFloat() * 1.8f, random.nextFloat() * 6.28f);
        }
    }

    @Override
    protected void init() {
        openedAt = System.currentTimeMillis();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        drawCosmicBackground(context, delta);

        // Header
        context.fill(24, 20, 28, 43, 0xFFB77CFF);
        context.drawTextWithShadow(textRenderer, "GLITCH", 38, 19, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "VISUAL", 38, 30, 0xFFCA9BFF);
        String edition = "JAVA EDITION  •  1.21.11";
        context.drawTextWithShadow(textRenderer, edition, width - textRenderer.getWidth(edition) - 24, 25, 0xFFB7A8D6);

        // Small navigation strip
        drawNavItem(context, "⌂  ГЛАВНАЯ", 25, 63, true);
        drawNavItem(context, "▣  БИБЛИОТЕКА", 133, 63, false);
        drawNavItem(context, "⚙  НАСТРОЙКИ", 265, 63, false);

        // Welcome title
        String welcome = "Добро пожаловать";
        context.drawCenteredTextWithShadow(textRenderer, welcome, width / 2, height / 4 + 10, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, "ТВОЯ ИГРА. ТВОЁ ПРОСТРАНСТВО.", width / 2, height / 4 + 28, 0xFFC9B3F6);

        int cy = height / 2 - 2;
        int gap = Math.min(116, width / 5);
        int[] centers = { width / 2 - gap, width / 2, width / 2 + gap };
        String[] icons = { "▶", "◎", "⚙" };
        String[] labels = { "Одиночная игра", "Сетевая игра", "Настройки" };
        String[] hints = { "Выбрать мир", "Подключиться", "Изменить параметры" };

        for (int i = 0; i < centers.length; i++) {
            int cx = centers[i];
            boolean hovered = mouseX >= cx - 42 && mouseX <= cx + 42 && mouseY >= cy - 42 && mouseY <= cy + 42;
            int glow = hovered ? 0x553D16FF : 0x332C0B72;
            drawCircle(context, cx, cy, hovered ? 45 : 41, glow);
            drawCircle(context, cx, cy, hovered ? 37 : 34, hovered ? 0xFFB77CFF : 0xAA7C54C9);
            drawCircle(context, cx, cy, 29, 0xCC17132B);
            context.drawCenteredTextWithShadow(textRenderer, icons[i], cx, cy - 5, 0xFFFFFFFF);
            context.drawCenteredTextWithShadow(textRenderer, labels[i], cx, cy + 54, hovered ? 0xFFFFFFFF : 0xFFE6DDF7);
            context.drawCenteredTextWithShadow(textRenderer, hints[i], cx, cy + 68, 0xFFB4A8CD);
        }

        // Lower info cards
        int cardY = height - 70;
        int cardW = Math.min(190, (width - 60) / 3);
        drawInfoCard(context, 24, cardY, cardW, "ПОСЛЕДНИЙ МИР", "Продолжить приключение");
        drawInfoCard(context, 36 + cardW, cardY, cardW, "СООБЩЕСТВО", "Играй вместе с друзьями");
        drawInfoCard(context, 48 + cardW * 2, cardY, cardW, "ПРОФИЛЬ", "GlitchVisual • Игрок");

        String footer = "GLITCHVISUAL  /  Создано для твоего мира";
        context.drawTextWithShadow(textRenderer, footer, 24, height - 15, 0xFF9D91B9);
        String quit = "ВЫХОД  ↗";
        context.drawTextWithShadow(textRenderer, quit, width - textRenderer.getWidth(quit) - 24, height - 15, 0xFFD8C9F4);
    }

    private void drawCosmicBackground(DrawContext context, float delta) {
        context.fillGradient(0, 0, width, height, 0xFF100A22, 0xFF050611);
        // Purple ambient light beams
        context.fillGradient(width / 8, 0, width / 2, height, 0x333F1A78, 0x00000000);
        context.fillGradient(width / 2, 0, width * 3 / 4, height, 0x222B145A, 0x00000000);

        float time = (System.currentTimeMillis() - openedAt) / 1000.0f;
        for (Star star : stars) {
            int x = (int) (star.x * width);
            int y = (int) (star.y * height);
            float pulse = (float) (0.5 + 0.5 * Math.sin(time * 1.3 + star.phase));
            int alpha = 80 + (int) (pulse * 150);
            int color = (alpha << 24) | (0xC6A8FF);
            int size = Math.max(1, (int) star.size);
            context.fill(x, y, x + size, y + size, color);
            if (star.size > 1.6f && pulse > 0.72f) {
                context.fill(x - 2, y, x + 3, y + 1, 0x88D8C5FF);
                context.fill(x, y - 2, x + 1, y + 3, 0x88D8C5FF);
            }
        }
        // Subtle bottom vignette
        context.fillGradient(0, height - 110, width, height, 0x00000000, 0xAA03030A);
    }

    private void drawNavItem(DrawContext context, String text, int x, int y, boolean active) {
        int color = active ? 0xFFFFFFFF : 0xFF9E92B8;
        if (active) context.fill(x - 7, y - 5, x + textRenderer.getWidth(text) + 7, y + 13, 0x553F2469);
        context.drawTextWithShadow(textRenderer, text, x, y, color);
    }

    private void drawInfoCard(DrawContext context, int x, int y, int w, String title, String subtitle) {
        int h = 42;
        context.fill(x, y, x + w, y + h, 0x77312A4A);
        context.fill(x, y, x + w, y + 1, 0x887E5DB6);
        context.drawTextWithShadow(textRenderer, title, x + 9, y + 7, 0xFFE3D7FF);
        context.drawTextWithShadow(textRenderer, subtitle, x + 9, y + 22, 0xFFB5A8D0);
    }

    private void drawCircle(DrawContext context, int cx, int cy, int radius, int color) {
        for (int dy = -radius; dy <= radius; dy++) {
            int dx = (int) Math.sqrt((double) radius * radius - (double) dy * dy);
            context.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, color);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        int cy = height / 2 - 2;
        int gap = Math.min(116, width / 5);
        int[] centers = { width / 2 - gap, width / 2, width / 2 + gap };
        for (int i = 0; i < centers.length; i++) {
            double dx = mouseX - centers[i];
            double dy = mouseY - cy;
            if (dx * dx + dy * dy <= 45 * 45) {
                MinecraftClient client = MinecraftClient.getInstance();
                switch (i) {
                    case 0 -> client.setScreen(new SelectWorldScreen(this));
                    case 1 -> client.setScreen(new MultiplayerScreen(this));
                    case 2 -> client.setScreen(new OptionsScreen(this, client.options));
                }
                return true;
            }
        }

        String quit = "ВЫХОД  ↗";
        int qx = width - textRenderer.getWidth(quit) - 24;
        if (mouseX >= qx && mouseY >= height - 25) {
            MinecraftClient.getInstance().scheduleStop();
            return true;
        }

        // Top navigation settings shortcut
        if (mouseY >= 55 && mouseY <= 85 && mouseX >= 250 && mouseX <= 380) {
            MinecraftClient client = MinecraftClient.getInstance();
            client.setScreen(new OptionsScreen(this, client.options));
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void close() {
        // Prevent Escape from dropping the player back into the vanilla title screen.
        MinecraftClient.getInstance().setScreen(this);
    }

    private record Star(float x, float y, float size, float phase) {}
}
