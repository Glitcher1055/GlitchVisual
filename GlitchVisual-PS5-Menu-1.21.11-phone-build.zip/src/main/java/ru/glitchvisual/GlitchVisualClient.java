package ru.glitchvisual;

import net.fabricmc.api.ClientModInitializer;

public final class GlitchVisualClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Точка входа оставлена для будущей регистрации HUD и модулей.
    }
}
