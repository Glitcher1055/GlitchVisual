Сюда (необязательно) можно положить ViaFabricPlus-4.4.15.jar - иначе GitHub Actions скачает его сам.
