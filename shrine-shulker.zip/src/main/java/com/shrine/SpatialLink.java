package com.shrine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Bridge to the bundled Spatial GUI mod (nested jar). Its settings live ONLY in our "Visual" tab:
 *  - pull(): config values -> our window, push(): our window -> SpatialGUIConfig.HANDLER (and saved to its file),
 *  - lock(): its own "open config" key is kept unbound, so its YACL screen can't be opened in game.
 * Reflection only: no compile-time dependency on the nested jars.
 */
final class SpatialLink {
    private SpatialLink() {}

    /** Config fields shown in the Visual tab (name -> our ShrineCfg key "sg.<name>"). */
    private static final String[] FIELDS = {
            "enabled", "inventory", "containers", "pauseScreen",
            "screenDistance", "screenSideOffset", "screenHeightOffset", "screenYawOffset", "screenPitchOffset", "screenScale",
            "cameraDistance", "cameraSideOffset", "cameraHeightOffset",
            "firstPersonScreenDistance", "firstPersonScreenScale",
            "enableScaleAnimation", "enableFadeAnimation", "enableCloseAnimation", "openAnimationDurationMs",
            "screenAlpha", "dropShadowEnabled", "curvedScreenEnabled", "hideHud", "hideHotbar"};

    static String K(String field) { return "sg." + field; }

    private static Object handler() throws Exception {
        Class<?> cfg = Class.forName("org.tastytrash.spatialGUI.client.SpatialGUIConfig");
        Field f = cfg.getDeclaredField("HANDLER");
        f.setAccessible(true);
        return f.get(null);
    }

    private static Object call(Object target, String iface, String name) throws Exception {
        Method m = Class.forName(iface).getMethod(name);
        return m.invoke(target);
    }

    private static final String HANDLER_IFACE = "dev.isxander.yacl3.config.v2.api.ConfigClassHandler";

    /** Spatial GUI config -> our window (called when the window opens). */
    static void pull() {
        try {
            Object inst = call(handler(), HANDLER_IFACE, "instance");
            for (String n : FIELDS) {
                Field f = inst.getClass().getField(n);
                Class<?> t = f.getType();
                if (t == boolean.class) ShrineCfg.setBool(K(n), f.getBoolean(inst));
                else if (t == int.class) ShrineCfg.setNum(K(n), f.getInt(inst));
                else if (t == double.class) ShrineCfg.setNum(K(n), (float) f.getDouble(inst));
            }
        } catch (Throwable ignored) { }
    }

    /** Our window -> Spatial GUI config, saved to its own file. */
    static void push() {
        try {
            Object h = handler();
            Object inst = call(h, HANDLER_IFACE, "instance");
            for (String n : FIELDS) {
                Field f = inst.getClass().getField(n);
                Class<?> t = f.getType();
                if (t == boolean.class) f.setBoolean(inst, ShrineCfg.bool(K(n), f.getBoolean(inst)));
                else if (t == int.class) f.setInt(inst, Math.round(ShrineCfg.num(K(n), f.getInt(inst))));
                else if (t == double.class) f.setDouble(inst, ShrineCfg.num(K(n), (float) f.getDouble(inst)));
            }
            call(h, HANDLER_IFACE, "save");
            ShrineCfg.save();
        } catch (Throwable ignored) { }
    }

    private static Field cfgKey;
    private static boolean cfgKeyMissing;

    /** Called every client tick: Spatial GUI's "open config" key stays unbound (Controls can't keep a binding). */
    static void lock(MinecraftClient c) {
        if (cfgKeyMissing) return;
        try {
            if (cfgKey == null) {
                cfgKey = Class.forName("org.tastytrash.spatialGUI.client.SpatialGUIKeybinds").getDeclaredField("openConfig");
                cfgKey.setAccessible(true);
            }
            if (!(cfgKey.get(null) instanceof KeyBinding kb)) return;
            if (!kb.isUnbound()) {
                kb.setBoundKey(InputUtil.UNKNOWN_KEY);
                KeyBinding.updateKeysByCode();
                if (c.options != null) c.options.write();
            }
            while (kb.wasPressed()) { /* swallow */ }
        } catch (ClassNotFoundException | NoSuchFieldException e) {
            cfgKeyMissing = true;       // mod missing / renamed: nothing to lock
        } catch (Throwable ignored) { }
    }
}
