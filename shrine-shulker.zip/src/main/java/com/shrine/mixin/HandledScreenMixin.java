package com.shrine.mixin;

import com.shrine.ShulkerPreview;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.slot.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Shulker Preview: draws the preview after the inventory and hides the vanilla tooltip of a shulker box. */
@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin {
    @Shadow protected Slot focusedSlot;

    @Inject(method = "render", at = @At("TAIL"))
    private void shrine$shulkerRender(DrawContext ctx, int mx, int my, float delta, CallbackInfo ci) {
        ShulkerPreview.onRender(ctx, (HandledScreen<?>) (Object) this, focusedSlot, mx, my);
    }

    @Inject(method = "drawMouseoverTooltip", at = @At("HEAD"), cancellable = true, require = 0)
    private void shrine$noTooltip(DrawContext ctx, int mx, int my, CallbackInfo ci) {
        if (ShulkerPreview.suppressTooltip(focusedSlot)) ci.cancel();
    }

    /** While the shulker window is open, clicks go to the window (take items out) and not to the inventory behind it. */
    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true, require = 0)
    private void shrine$shulkerClick(Click click, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
        if (ShulkerPreview.click(click.x(), click.y(), click.button())) cir.setReturnValue(true);
    }
}
