package com.shrine.mixin;

import com.shrine.WorldCreateFx;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * "Message" screens ("Сохранение мира" ...) draw their title with the vanilla pixel font. Our backdrop already draws it
 * in the PS5 style, so the vanilla centered text is skipped there. (Targets one exact signature: if the game's
 * method differs the injection is skipped silently and nothing breaks.)
 */
@Mixin(DrawContext.class)
public class DrawContextTextMixin {
    @Inject(method = "drawCenteredTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;III)V",
            at = @At("HEAD"), cancellable = true)
    private void shrine$hideVanillaTitle(TextRenderer tr, Text text, int x, int y, int color, CallbackInfo ci) {
        if (WorldCreateFx.messageScreen()) ci.cancel();
    }
}
