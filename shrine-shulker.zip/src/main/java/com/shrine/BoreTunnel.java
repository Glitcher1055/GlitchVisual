package com.shrine;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

/**
 * Built-in TCP tunnel (client of the open "bore" protocol, pure Java, no accounts, works on Android launchers).
 * Friends connect to host:remotePort and the traffic is carried to the local LAN port of the world.
 * Messages on the control port (7835) are JSON objects ended with a 0 byte.
 */
final class BoreTunnel {
    static final int CONTROL_PORT = 7835;

    private final String host;
    private final int localPort, wantPort;
    private volatile boolean running;
    private final Set<Socket> sockets = ConcurrentHashMap.newKeySet();

    BoreTunnel(String host, int localPort, int wantPort) {
        this.host = host; this.localPort = localPort; this.wantPort = wantPort;
    }

    void start(IntConsumer onReady, Consumer<String> onError) {
        running = true;
        Thread t = new Thread(() -> {
            try {
                Socket control = connect(host, CONTROL_PORT);
                control.setSoTimeout(15000);   // the server sends a heartbeat every ~0.5 s
                OutputStream out = control.getOutputStream();
                InputStream in = control.getInputStream();
                send(out, "{\"Hello\":" + wantPort + "}");
                String first = recv(in);
                if (first == null) throw new IOException("Сервер туннеля закрыл соединение");
                JsonElement e = JsonParser.parseString(first);
                if (e.isJsonObject() && e.getAsJsonObject().has("Hello")) {
                    onReady.accept(e.getAsJsonObject().get("Hello").getAsInt());
                } else if (e.isJsonObject() && e.getAsJsonObject().has("Error")) {
                    throw new IOException(e.getAsJsonObject().get("Error").getAsString());
                } else {
                    throw new IOException("Неожиданный ответ сервера туннеля");
                }
                while (running) {
                    String m = recv(in);
                    if (m == null) break;
                    JsonElement j = JsonParser.parseString(m);
                    if (j.isJsonObject() && j.getAsJsonObject().has("Connection")) {
                        String id = j.getAsJsonObject().get("Connection").getAsString();
                        Thread h = new Thread(() -> accept(id), "shrine-bore-conn");
                        h.setDaemon(true);
                        h.start();
                    }
                }
                if (running) onError.accept("Туннель закрыт сервером");
            } catch (Exception ex) {
                if (running) onError.accept(ex.getMessage() == null ? "Ошибка туннеля" : ex.getMessage());
            }
        }, "shrine-bore");
        t.setDaemon(true);
        t.start();
    }

    void stop() {
        running = false;
        for (Socket s : sockets) close(s);
        sockets.clear();
    }

    /** A friend connected: open a data connection to the server and glue it to the local world port. */
    private void accept(String id) {
        Socket remote = null, local = null;
        try {
            remote = connect(host, CONTROL_PORT);
            send(remote.getOutputStream(), "{\"Accept\":\"" + id + "\"}");
            local = new Socket();
            local.setTcpNoDelay(true);
            local.connect(new InetSocketAddress("127.0.0.1", localPort), 5000);
            sockets.add(local);
            pipe(remote, local);
            pipe(local, remote);
        } catch (Exception ex) {
            close(remote); close(local);
        }
    }

    private void pipe(Socket from, Socket to) {
        Thread t = new Thread(() -> {
            byte[] buf = new byte[8192];
            try {
                InputStream in = from.getInputStream();
                OutputStream out = to.getOutputStream();
                int n;
                while ((n = in.read(buf)) >= 0) { out.write(buf, 0, n); out.flush(); }
            } catch (Exception ignored) {
            } finally { close(from); close(to); }
        }, "shrine-bore-pipe");
        t.setDaemon(true);
        t.start();
    }

    private Socket connect(String h, int port) throws IOException {
        Socket s = new Socket();
        s.setTcpNoDelay(true);
        s.connect(new InetSocketAddress(h, port), 10000);
        sockets.add(s);
        return s;
    }

    private void close(Socket s) {
        if (s == null) return;
        sockets.remove(s);
        try { s.close(); } catch (Exception ignored) { }
    }

    private static void send(OutputStream out, String json) throws IOException {
        out.write(json.getBytes(StandardCharsets.UTF_8));
        out.write(0);
        out.flush();
    }

    /** Reads one 0-terminated message byte by byte (nothing beyond the message is consumed). null = connection closed. */
    private static String recv(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int c;
        while ((c = in.read()) >= 0) {
            if (c == 0) return b.toString(StandardCharsets.UTF_8);
            if (b.size() > 8192) throw new IOException("Слишком длинное сообщение");
            b.write(c);
        }
        return null;
    }
}
