package com.shrine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.GameMode;

import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.List;

/** Play with friends: opens the world to LAN and carries it out through the built-in tunnel. No setup needed. */
final class FriendsHost {
    private FriendsHost() {}

    static final String K_SERVER = "friends.server", K_RPORT = "friends.rport", K_PIRATES = "friends.pirates";

    private static BoreTunnel tunnel;
    private static volatile boolean hosting, ready;
    static volatile String error = "";

    static boolean hosting() { return hosting; }
    static boolean ready() { return ready; }
    static boolean pirates() { return ShrineCfg.bool(K_PIRATES, true); }

    /** The link for friends (same port every time while it is free). Empty until the first start. */
    static String address() {
        int p = ShrineCfg.integer(K_RPORT, 0);
        return p > 0 ? ShrineCfg.str(K_SERVER, "bore.pub").trim() + ":" + p : "";
    }

    static void start() {
        error = "";
        MinecraftClient mc = MinecraftClient.getInstance();
        IntegratedServer srv = mc.getServer();
        if (srv == null) { error = "Только в одиночном мире"; return; }
        int local;
        if (srv.isRemote()) {
            local = srv.getServerPort();               // already open to LAN (vanilla "Open to LAN")
        } else {
            local = freePort();
            GameMode gm = mc.interactionManager != null ? mc.interactionManager.getCurrentGameMode() : GameMode.SURVIVAL;
            if (local <= 0 || !srv.openToLan(gm, false, local)) { error = "Не удалось открыть мир для сети"; return; }
        }
        srv.setOnlineMode(!pirates());
        stopTunnel();
        ready = false;
        hosting = true;
        launch(local, ShrineCfg.integer(K_RPORT, 0), true);
    }

    private static void launch(int local, int want, boolean retry) {
        BoreTunnel t = new BoreTunnel(ShrineCfg.str(K_SERVER, "bore.pub").trim(), local, want);
        tunnel = t;
        t.start(port -> {
            ShrineCfg.setInt(K_RPORT, port);
            ShrineCfg.save();
            ready = true;
        }, msg -> {
            if (tunnel != t) return;
            if (!ready && want > 0 && retry) { t.stop(); launch(local, 0, false); return; }   // the old port is taken: get a new one
            error = msg;
            ready = false;
            hosting = false;
            t.stop();
        });
    }

    static void stop() { stopTunnel(); hosting = false; ready = false; }

    private static void stopTunnel() {
        if (tunnel != null) { tunnel.stop(); tunnel = null; }
    }

    private static int freePort() {
        try (ServerSocket s = new ServerSocket(0)) { return s.getLocalPort(); } catch (Exception e) { return -1; }
    }

    static void setPirates(boolean v) {
        ShrineCfg.setBool(K_PIRATES, v);
        ShrineCfg.save();
        IntegratedServer srv = MinecraftClient.getInstance().getServer();
        if (srv != null) srv.setOnlineMode(!v);
    }

    /** Names of the connected friends (without yourself). */
    static List<String> players() {
        List<String> out = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();
        IntegratedServer srv = mc.getServer();
        if (srv == null || !hosting) return out;
        String me = mc.getSession().getUsername();
        for (ServerPlayerEntity p : srv.getPlayerManager().getPlayerList()) {
            String n = p.getName().getString();
            if (!n.equals(me)) out.add(n);
        }
        return out;
    }
}
