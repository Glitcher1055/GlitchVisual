package com.shrine;

import com.shrine.Gfx.Fnt;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.List;

import static com.shrine.Gfx.*;

/**
 * Glass dialog with a scrollable list of Minecraft versions (from ViaFabricPlus).
 * Two uses: GLOBAL (the version the whole client speaks) and SERVER (pin a version to one server;
 * the first row "По умолчанию" removes the pin).
 */
final class VersionPicker {
    enum Mode { GLOBAL, SERVER }

    private static final float W = 400f, H = 440f, ROW = 38f, GAP = 4f, LIST_TOP = 66f, LIST_BOTTOM = 26f;

    final Mode mode;
    /** Chosen ProtocolVersion; null means "по умолчанию" (only valid in SERVER mode). */
    Object value;

    private final Object current;             // what is highlighted when the picker opens
    private final List<Row> rows = new ArrayList<>();
    private final long openedAt = Util.getMeasuringTimeMs();
    private float scroll, scrollTarget;
    private float x, y;
    private float[] rClose = new float[4];
    private float[] rList = new float[4];
    private boolean scrolledToCurrent;

    private record Row(Via.Ver ver, String label) {}

    VersionPicker(Mode mode, Object current) {
        this.mode = mode;
        this.current = current;
        if (mode == Mode.SERVER) rows.add(new Row(null, "По умолчанию (как в клиенте)"));
        for (Via.Ver v : Via.versions()) rows.add(new Row(v, v.name()));
    }

    float alpha() {
        float t = Math.min(1f, (Util.getMeasuringTimeMs() - openedAt) / 200f);
        return 1f - (1f - t) * (1f - t);
    }

    private boolean isCurrent(Row r) {
        if (r.ver == null) return current == null;
        return current != null && current.equals(r.ver.pv());
    }

    private float listHeight() { return H - LIST_TOP - LIST_BOTTOM; }
    private float contentHeight() { return rows.size() * (ROW + GAP) - GAP; }
    private float maxScroll() { return Math.max(0f, contentHeight() - listHeight()); }

    void draw(DrawContext ctx, TextRenderer tr, float vw, float mx, float my, float a, float delta) {
        x = (vw - W) / 2f;
        y = (Scene.REF_H - H) / 2f - 8f + (1f - a) * 14f;

        if (!scrolledToCurrent) {   // open with the current version in the middle of the list
            scrolledToCurrent = true;
            for (int i = 0; i < rows.size(); i++) {
                if (isCurrent(rows.get(i))) {
                    scrollTarget = Math.max(0f, Math.min(maxScroll(), i * (ROW + GAP) - listHeight() / 2f + ROW / 2f));
                    scroll = scrollTarget;
                    break;
                }
            }
        }
        scroll += (scrollTarget - scroll) * Math.min(1f, delta * 0.35f);

        box(ctx, RR, x - 1, y - 1, W + 2, H + 2, 27, argb(0.10f * a, 0xFFFFFF));
        box(ctx, RR, x, y, W, H, 26, argb(0.97f * a, 0x1A1116));
        text(ctx, tr, Fnt.UI_B, mode == Mode.GLOBAL ? "Версия клиента" : "Версия для сервера", x + 24, y + 33, argb(a, 0xFFFFFF));
        text(ctx, tr, Fnt.SMALL, mode == Mode.GLOBAL ? "На эту версию подключается игра по умолчанию"
                : "Закрепляется за этим сервером", x + 24, y + 54, argb(0.50f * a, 0xFFFFFF));

        float cx = x + W - 30, cy = y + 33;
        boolean hc = Gfx.inside(mx, my, cx - 14, cy - 14, 28, 28);
        centered(ctx, DISC, cx, cy, 22, 22, argb((hc ? 1f : 0.88f) * a, 0xFF6B6B));
        textC(ctx, tr, Fnt.TINY_B, "×", cx, cy - 0.5f, argb(a, 0x2A0A0A));
        rClose = new float[]{cx - 14, cy - 14, 28, 28};

        float lt = y + LIST_TOP, lh = listHeight();
        rList = new float[]{x + 12, lt, W - 24, lh};
        if (rows.isEmpty()) {
            textC(ctx, tr, Fnt.LABEL, "Список версий недоступен", x + W / 2, lt + 40, argb(0.5f * a, 0xFFFFFF));
            return;
        }
        boolean overList = Gfx.inside(mx, my, rList[0], rList[1], rList[2], rList[3]);
        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            float ry = lt + i * (ROW + GAP) - scroll;
            float center = ry + ROW / 2f;
            // no scissor: rows fade out as their centre approaches the edge of the list
            float edge = Math.min(center - lt, lt + lh - center);
            float fa = Math.max(0f, Math.min(1f, edge / (ROW / 2f + 10f)));
            if (fa <= 0.01f) continue;
            float f = a * fa;
            boolean cur = isCurrent(r);
            boolean hov = overList && Gfx.inside(mx, my, x + 12, ry, W - 24, ROW);
            if (cur) box(ctx, RR, x + 12, ry, W - 24, ROW, 12, argb(0.96f * f, 0xFFFFFF));
            else if (hov) box(ctx, RR, x + 12, ry, W - 24, ROW, 12, argb(0.14f * f, 0xFFFFFF));
            if (hov && !cur) box(ctx, RR_RING, x + 12, ry, W - 24, ROW, 12, argb(0.45f * f, 0xFFFFFF));
            text(ctx, tr, Fnt.UI, r.label, x + 30, ry + ROW / 2f, argb(f, cur ? 0x14101A : 0xFFFFFF));
            if (cur) centered(ctx, DISC, x + W - 36, ry + ROW / 2f, 10, 10, argb(f, 0x14101A));
        }

        // thin scrollbar
        float max = maxScroll();
        if (max > 0f) {
            float th = Math.max(26f, lh * lh / contentHeight());
            float ty = lt + (lh - th) * (scroll / max);
            box(ctx, RR, x + W - 9, ty, 3, th, 1.5f, argb(0.35f * a, 0xFFFFFF));
        }
    }

    /** @return 0 = nothing; 1 = close without changes; 2 = a version was chosen (see {@link #value}) */
    int click(double mx, double my) {
        if (Gfx.inside(mx, my, rClose[0], rClose[1], rClose[2], rClose[3])) return 1;
        if (!Gfx.inside(mx, my, rList[0], rList[1], rList[2], rList[3])) return 0;
        for (int i = 0; i < rows.size(); i++) {
            float ry = rList[1] + i * (ROW + GAP) - scroll;
            if (Gfx.inside(mx, my, x + 12, ry, W - 24, ROW)) {
                Row r = rows.get(i);
                value = r.ver == null ? null : r.ver.pv();
                return 2;
            }
        }
        return 0;
    }

    void scroll(double amount) {
        scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget - (float) amount * 80f));
    }
}
