package com.shrine;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Shared drawing helpers: smooth textures, 9-slice rounded boxes, TTF text placed by vertical center. */
final class Gfx {
    private Gfx() {}

    static final int ACCENT = 0xFF3A3A;

    static Identifier tex(String n) { return Identifier.of("shrine", "textures/gui/" + n + ".png"); }

    static final Identifier DISC = tex("disc"), RING = tex("ring"), GLOW = tex("glow"), DOT = tex("dot"),
            BEAM = tex("beam"), LOGO = tex("logo"), RR = tex("rr"), RR_RING = tex("rr_ring"),
            I_GEAR = tex("icon_gear"), I_CHAT = tex("icon_chat"), I_ACTIVITY = tex("icon_activity"),
            I_FRIENDS = tex("icon_friends"), I_ENTER = tex("icon_enter"),
            ICO_ONLINE = tex("ico_online"), ICO_SKIN = tex("ico_skin"), ICO_SOUND = tex("ico_sound"), ICO_VIDEO = tex("ico_video"),
            ICO_CONTROLS = tex("ico_controls"), ICO_LANGUAGE = tex("ico_language"), ICO_PACK = tex("ico_pack"),
            ICO_ACCESS = tex("ico_access"), ICO_DATA = tex("ico_data"), ICO_INFO = tex("ico_info");

    /** TTF fonts (see assets/shrine/font). Glyph baseline sits ~7 units below the draw y, so we place by center. */
    enum Fnt {
        TITLE("title", 27), TITLE_B("title_bold", 27), LABEL("label", 17), SMALL("small", 12),
        UI("ui", 20), UI_B("ui_bold", 20), NAME_B("name_bold", 34), TINY_B("tiny_bold", 15),
        TILE_S("tile_s", 24), TILE_L("tile_l", 40), HUGE("huge", 72);

        final Identifier id; final float size;
        Fnt(String n, float size) { this.id = Identifier.of("shrine", n); this.size = size; }
        Text of(String s) { return Text.literal(s).setStyle(Style.EMPTY.withFont(new StyleSpriteSource.Font(id))); }
    }

    static int argb(float a, int rgb) {
        int al = Math.round(Math.max(0f, Math.min(1f, a)) * 255f);
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    static void blit(DrawContext ctx, Identifier id, int x, int y, int w, int h, int color) {
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, id, x, y, 0f, 0f, w, h, 1, 1, 1, 1, color);
    }

    static void centered(DrawContext ctx, Identifier id, float cx, float cy, float w, float h, int color) {
        blit(ctx, id, Math.round(cx - w / 2f), Math.round(cy - h / 2f),
                Math.max(1, Math.round(w)), Math.max(1, Math.round(h)), color);
    }

    /** Rounded box from a 128px 9-slice texture (corner = 48px). */
    static void box(DrawContext ctx, Identifier id, float x, float y, float w, float h, float r, int color) {
        final int T = 128, C = 48;
        r = Math.min(r, Math.min(w, h) / 2f);
        int x0 = Math.round(x), y0 = Math.round(y), x1 = Math.round(x + w), y1 = Math.round(y + h), ri = Math.round(r);
        int[] dx = {x0, x0 + ri, x1 - ri, x1};
        int[] dy = {y0, y0 + ri, y1 - ri, y1};
        int[] s = {0, C, T - C, T};
        for (int j = 0; j < 3; j++) {
            for (int i = 0; i < 3; i++) {
                int dw = dx[i + 1] - dx[i], dh = dy[j + 1] - dy[j];
                if (dw <= 0 || dh <= 0) continue;
                ctx.drawTexture(RenderPipelines.GUI_TEXTURED, id, dx[i], dy[j], (float) s[i], (float) s[j],
                        dw, dh, s[i + 1] - s[i], s[j + 1] - s[j], T, T, color);
            }
        }
    }

    /**
     * Paints the plain menu gradient over the whole screen. Call it in the frame where a screen hands over to another
     * one and then returns without drawing: otherwise that single frame shows the vanilla background (a flash).
     */
    static void cover(DrawContext ctx, int w, int h) { ctx.fillGradient(0, 0, w, h, 0xFF0C0205, 0xFF1E0509); }

    static int width(TextRenderer tr, Fnt f, String s) { return tr.getWidth(f.of(s)); }

    /** Left-aligned at x, vertically centered on cy. */
    static void text(DrawContext ctx, TextRenderer tr, Fnt f, String s, float x, float cy, int color) {
        float y = cy - 7f + f.size * 0.32f;
        ctx.drawText(tr, f.of(s), Math.round(x), Math.round(y), color, false);
    }

    static void textC(DrawContext ctx, TextRenderer tr, Fnt f, String s, float cx, float cy, int color) {
        text(ctx, tr, f, s, cx - width(tr, f, s) / 2f, cy, color);
    }

    static boolean inside(double mx, double my, float x, float y, float w, float h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }
}
