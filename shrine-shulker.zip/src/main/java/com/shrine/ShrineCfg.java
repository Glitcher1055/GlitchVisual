package com.shrine;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Tiny key/value store for the settings window (config/shrine.properties). */
final class ShrineCfg {
    private ShrineCfg() {}

    private static final Properties P = new Properties();
    private static boolean loaded;

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("shrine.properties"); }

    private static void load() {
        if (loaded) return;
        loaded = true;
        try (InputStream in = Files.newInputStream(file())) { P.load(in); } catch (Throwable ignored) { }
    }

    static void save() {
        try (OutputStream out = Files.newOutputStream(file())) { P.store(out, "Shrine"); } catch (Throwable ignored) { }
    }

    static String str(String k, String def) { load(); return P.getProperty(k, def); }
    static void setStr(String k, String v) { load(); P.setProperty(k, v); }

    static boolean bool(String k, boolean def) { load(); return Boolean.parseBoolean(P.getProperty(k, String.valueOf(def))); }
    static void setBool(String k, boolean v) { load(); P.setProperty(k, String.valueOf(v)); }

    static float num(String k, float def) {
        load();
        try { return Float.parseFloat(P.getProperty(k, String.valueOf(def))); } catch (Throwable t) { return def; }
    }
    static void setNum(String k, float v) { load(); P.setProperty(k, String.valueOf(v)); }

    static int integer(String k, int def) { return Math.round(num(k, def)); }
    static void setInt(String k, int v) { setNum(k, v); }
}
