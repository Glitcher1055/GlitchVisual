package com.shrine;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.network.ServerInfo;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Thin reflection bridge to ViaFabricPlus. Reflection keeps this mod compiling and running without VFP:
 * when VFP is missing, {@link #available()} is false and every version button simply disappears.
 *
 * Used VFP API:
 *  - ViaFabricPlus.getImpl().getTargetVersion() / setTargetVersion(pv)  - global client version
 *  - IServerData.viaFabricPlus$forcedVersion() / viaFabricPlus$forceVersion(pv) - version pinned to one server
 *    (VFP mixes IServerData into ServerInfo and saves it into servers.dat itself)
 *  - ProtocolVersion.getReversedProtocols(), getName(), getVersion()
 */
final class Via {
    private Via() {}

    /** One selectable protocol version. {@code pv} is a ViaVersion ProtocolVersion (kept as Object on purpose). */
    record Ver(Object pv, String name, int id) {}

    private static boolean tried, ok;
    private static Class<?> cPv, cServerData;
    private static Method mReversed, mName, mId, mGetImpl, mGetTarget, mSetTarget, mForced, mForce;
    private static List<Ver> cache;

    static boolean available() {
        if (tried) return ok;
        tried = true;
        try {
            if (!FabricLoader.getInstance().isModLoaded("viafabricplus")) return false;
            cPv = Class.forName("com.viaversion.viaversion.api.protocol.version.ProtocolVersion");
            cServerData = Class.forName("com.viaversion.viafabricplus.injection.access.base.IServerData");
            Class<?> cVfp = Class.forName("com.viaversion.viafabricplus.ViaFabricPlus");
            Class<?> cBase = Class.forName("com.viaversion.viafabricplus.api.ViaFabricPlusBase");
            mReversed = cPv.getMethod("getReversedProtocols");
            mName = cPv.getMethod("getName");
            mId = cPv.getMethod("getVersion");
            mGetImpl = cVfp.getMethod("getImpl");
            mGetTarget = cBase.getMethod("getTargetVersion");
            mSetTarget = cBase.getMethod("setTargetVersion", cPv);
            mForced = cServerData.getMethod("viaFabricPlus$forcedVersion");
            mForce = cServerData.getMethod("viaFabricPlus$forceVersion", cPv);
            ok = true;
        } catch (Throwable t) {
            ok = false;
        }
        return ok;
    }

    /** All versions, newest first. */
    static List<Ver> versions() {
        if (!available()) return Collections.emptyList();
        if (cache != null) return cache;
        List<Ver> out = new ArrayList<>();
        try {
            for (Object pv : (List<?>) mReversed.invoke(null)) out.add(wrap(pv));
        } catch (Throwable ignored) {
            // leave the list empty: the picker will just show nothing
        }
        return cache = out;
    }

    private static Ver wrap(Object pv) throws Exception {
        return new Ver(pv, (String) mName.invoke(pv), (Integer) mId.invoke(pv));
    }

    static String nameOf(Object pv) {
        if (pv == null || !available()) return "";
        try { return (String) mName.invoke(pv); } catch (Throwable t) { return ""; }
    }

    /** Version the whole client currently speaks (what the "global" button changes). */
    static Object global() {
        if (!available()) return null;
        try { return mGetTarget.invoke(mGetImpl.invoke(null)); } catch (Throwable t) { return null; }
    }

    static void setGlobal(Object pv) {
        if (!available() || pv == null) return;
        try { mSetTarget.invoke(mGetImpl.invoke(null), pv); } catch (Throwable ignored) { }
    }

    /** Version pinned to this server, or null when it follows the global one. */
    static Object forced(ServerInfo si) {
        if (!available() || si == null || !cServerData.isInstance(si)) return null;
        try { return mForced.invoke(si); } catch (Throwable t) { return null; }
    }

    /** Pin a version to this server (null = unpin). VFP writes it to servers.dat on the next save. */
    static void force(ServerInfo si, Object pv) {
        if (!available() || si == null || !cServerData.isInstance(si)) return;
        try { mForce.invoke(si, pv); } catch (Throwable ignored) { }
    }
}
