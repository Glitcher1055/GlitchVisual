package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.block.Block;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.ChatScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

import java.util.Arrays;
import java.util.List;

import static com.shrine.Gfx.*;

/**
 * HUD > "Shulker Preview": hover a shulker box in any inventory and its contents show as a 9x3 grid instead of the
 * vanilla tooltip. The preview key (V by default, changeable in Controls) opens a window tinted with the colour of the
 * box; hover any slot there for the full item tooltip. Also works for the box in your hand (no screen open).
 * Modes: toggle (press to open / close) or hold.
 */
final class ShulkerPreview {
    private ShulkerPreview() {}

    static final String KEY = "hud.shulker", K_HOVER = "hud.shulker.hover", K_HELD = "hud.shulker.held",
            K_MODE = "hud.shulker.mode", K_TINT = "hud.shulker.tint", K_SCALE = "hud.shulker.scale";
    static final String[] MODES = {"Переключение", "Удержание"};

    private static final int COLS = 9, ROWS = 3;
    private static final float SLOT = 22f, GAP = 2f, PAD = 10f, HEAD = 44f, BAR = 14f;
    private static final float W = PAD * 2f + COLS * SLOT + (COLS - 1) * GAP;
    private static final float GRID_Y = HEAD;
    private static final float H = GRID_Y + ROWS * SLOT + (ROWS - 1) * GAP + BAR + 12f;

    private static KeyBinding key;
    private static boolean wasDown, open;
    private static ItemStack winStack = ItemStack.EMPTY, focus = ItemStack.EMPTY;
    private static Screen winScreen;
    private static long openAt;

    static void register(KeyBinding.Category cat) {
        key = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.shrine.shulker", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, cat));
        ClientTickEvents.END_CLIENT_TICK.register(ShulkerPreview::tick);
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "shulker_preview"), (ctx, tick) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (open && mc.currentScreen == null && mc.player != null && !mc.options.hudHidden)
                drawWindow(ctx, mc, winStack, -1, -1, false);
        });
    }

    // ---------------- data ----------------
    static boolean isShulker(ItemStack st) {
        return st != null && !st.isEmpty() && st.getItem() instanceof BlockItem bi && bi.getBlock() instanceof ShulkerBoxBlock;
    }

    private static ItemStack[] contents(ItemStack st) {
        ItemStack[] out = new ItemStack[COLS * ROWS];
        Arrays.fill(out, ItemStack.EMPTY);
        ContainerComponent c = st.get(DataComponentTypes.CONTAINER);
        if (c != null) {
            List<ItemStack> l = c.stream().toList();
            for (int i = 0; i < Math.min(out.length, l.size()); i++) out[i] = l.get(i);
        }
        return out;
    }

    private static int tint(ItemStack st) {
        int c = 0xB07CFF;
        if (ShrineCfg.bool(K_TINT, true)) {
            Block b = ((BlockItem) st.getItem()).getBlock();
            DyeColor d = ((ShulkerBoxBlock) b).getColor();
            if (d != null) c = d.getSignColor() & 0xFFFFFF;
        }
        int lum = (((c >> 16) & 255) * 299 + ((c >> 8) & 255) * 587 + (c & 255) * 114) / 1000;
        return lum < 80 ? lerp(c, 0xFFFFFF, 0.45f) : c;
    }

    private static int lerp(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static float scale() { return Math.max(0.7f, Math.min(1.6f, ShrineCfg.num(K_SCALE, 1f))); }

    private static String keyName() {
        try { return KeyBindingHelper.getBoundKeyOf(key).getLocalizedText().getString(); } catch (Throwable t) { return "V"; }
    }

    // ---------------- input (every tick) ----------------
    private static ItemStack held(MinecraftClient mc) {
        if (mc.player == null || !ShrineCfg.bool(K_HELD, true)) return ItemStack.EMPTY;
        if (isShulker(mc.player.getMainHandStack())) return mc.player.getMainHandStack();
        if (isShulker(mc.player.getOffHandStack())) return mc.player.getOffHandStack();
        return ItemStack.EMPTY;
    }

    private static void close() { open = false; winStack = ItemStack.EMPTY; winScreen = null; }

    private static void tick(MinecraftClient mc) {
        Screen s = mc.currentScreen;
        if (s == null) focus = ItemStack.EMPTY;
        boolean down = false;
        if (key != null && mc.getWindow() != null) {
            int code = KeyBindingHelper.getBoundKeyOf(key).getCode();
            down = code != GLFW.GLFW_KEY_UNKNOWN && GLFW.glfwGetKey(mc.getWindow().getHandle(), code) == GLFW.GLFW_PRESS;
        }
        boolean typing = s instanceof ChatScreen || (s != null && s.getFocused() instanceof TextFieldWidget);
        if (!ShrineCfg.bool(KEY, true) || typing || (s != null && !(s instanceof HandledScreen))) {
            close(); wasDown = down; return;
        }
        boolean hold = ShrineCfg.integer(K_MODE, 0) == 1;
        if (down && !wasDown) {
            if (open && !hold) close();
            else {
                ItemStack target = s != null ? focus : held(mc);
                if (isShulker(target)) { open = true; winStack = target.copy(); winScreen = s; openAt = Util.getMeasuringTimeMs(); }
            }
        }
        if (!down && wasDown && hold) close();
        wasDown = down;
        if (open && s == null && !isShulker(held(mc))) close();
    }

    // ---------------- called from HandledScreenMixin ----------------
    static void onRender(DrawContext ctx, HandledScreen<?> screen, Slot focused, int mx, int my) {
        if (!ShrineCfg.bool(KEY, true)) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        focus = (focused != null && screen.getScreenHandler().getCursorStack().isEmpty()) ? focused.getStack() : ItemStack.EMPTY;
        if (open && winScreen != screen) close();
        if (open) { drawWindow(ctx, mc, winStack, mx, my, true); return; }
        if (ShrineCfg.bool(K_HOVER, true) && isShulker(focus)) drawHover(ctx, mc, focus, mx, my);
    }

    static boolean suppressTooltip(Slot focused) {
        if (!ShrineCfg.bool(KEY, true)) return false;
        if (open) return true;
        return ShrineCfg.bool(K_HOVER, true) && focused != null && isShulker(focused.getStack());
    }

    // ---------------- drawing ----------------
    private static void drawHover(DrawContext ctx, MinecraftClient mc, ItemStack st, int mx, int my) {
        float k = mc.getWindow().getScaledHeight() / Scene.REF_H, vw = mc.getWindow().getScaledWidth() / k, s = scale();
        float px = mx / k + 14f, py = my / k - 8f;
        if (px + W * s > vw - 4f) px = mx / k - 14f - W * s;
        px = Math.max(4f, px);
        py = Math.max(4f, Math.min(Scene.REF_H - H * s - 4f, py));
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        ctx.getMatrices().translate(px, py);
        ctx.getMatrices().scale(s, s);
        panel(ctx, mc.textRenderer, st, 1f, false, -1);
        ctx.getMatrices().popMatrix();
    }

    private static void drawWindow(DrawContext ctx, MinecraftClient mc, ItemStack st, int mx, int my, boolean screen) {
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        float k = sh / Scene.REF_H, vw = sw / k, s = scale() * 1.15f;
        float t = Math.min(1f, (Util.getMeasuringTimeMs() - openAt) / 160f), a = 1f - (1f - t) * (1f - t);
        float wx = vw / 2f - W * s / 2f, wy = Scene.REF_H / 2f - H * s / 2f + (1f - a) * 10f;
        int hover = -1;
        if (screen) {
            float mxv = mx / k, myv = my / k;
            for (int i = 0; i < COLS * ROWS; i++) {
                float x = wx + s * (PAD + (i % COLS) * (SLOT + GAP)), y = wy + s * (GRID_Y + (i / COLS) * (SLOT + GAP));
                if (inside(mxv, myv, x, y, SLOT * s, SLOT * s)) { hover = i; break; }
            }
            ctx.fillGradient(0, 0, sw, sh, argb(0.30f * a, 0x000000), argb(0.50f * a, 0x000000));
        }
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        ctx.getMatrices().translate(wx, wy);
        ctx.getMatrices().scale(s, s);
        panel(ctx, mc.textRenderer, st, a, true, hover);
        ctx.getMatrices().popMatrix();
        if (screen && hover >= 0 && a > 0.9f) {
            ItemStack it = contents(st)[hover];
            if (!it.isEmpty()) ctx.drawItemTooltip(mc.textRenderer, it, mx, my);
        }
    }

    /** The panel at origin (0,0): header, 9x3 grid, fill bar. window = glowing tinted window, otherwise a hover tooltip. */
    private static void panel(DrawContext ctx, TextRenderer tr, ItemStack st, float a, boolean window, int hover) {
        int tint = tint(st);
        ItemStack[] items = contents(st);
        int filled = 0, total = 0;
        for (ItemStack it : items) if (!it.isEmpty()) { filled++; total += it.getCount(); }

        if (window) centered(ctx, GLOW, W / 2f, H / 2f, W * 1.7f, H * 1.9f, argb(0.38f * a, tint));
        box(ctx, RR, -1, -1, W + 2, H + 2, 17, argb((window ? 0.70f : 0.45f) * a, tint));
        box(ctx, RR, 0, 0, W, H, 16, argb(0.94f * a, lerp(0x100A16, tint, 0.14f)));

        // header: box icon, name, count, hint
        box(ctx, RR, PAD, 9f, 26f, 26f, 8f, argb(0.30f * a, tint));
        if (a > 0.5f) item(ctx, st, PAD + 5f, 14f);
        String name = st.getName().getString();
        float right = window ? W - PAD : W - PAD - width(tr, Fnt.SMALL, "[" + keyName() + "] открыть") - 6f;
        float avail = right - (PAD + 34f) - (window ? 0f : 8f);
        while (name.length() > 3 && width(tr, Fnt.UI_B, name) > avail) name = name.substring(0, name.length() - 2) + "…";
        text(ctx, tr, Fnt.UI_B, name, PAD + 34f, 16f, argb(a, 0xFFFFFF));
        String sub = total == 0 ? "Пусто" : filled + "/" + (COLS * ROWS) + " · " + total + " предм.";
        text(ctx, tr, Fnt.SMALL, sub, PAD + 34f, 32f, argb(0.60f * a, 0xFFFFFF));
        if (!window) {
            String hint = "[" + keyName() + "] открыть";
            text(ctx, tr, Fnt.SMALL, hint, W - PAD - width(tr, Fnt.SMALL, hint), 16f, argb(0.55f * a, tint));
        }

        // grid
        for (int i = 0; i < COLS * ROWS; i++) {
            float sx = PAD + (i % COLS) * (SLOT + GAP), sy = GRID_Y + (i / COLS) * (SLOT + GAP);
            box(ctx, RR, sx, sy, SLOT, SLOT, 7, argb(0.45f * a, lerp(0x000000, tint, 0.18f)));
            box(ctx, RR_RING, sx, sy, SLOT, SLOT, 7, argb((i == hover ? 0.85f : 0.28f) * a, i == hover ? 0xFFFFFF : tint));
            ItemStack it = items[i];
            if (it.isEmpty() || a < 0.5f) continue;
            item(ctx, it, sx + (SLOT - 16f) / 2f, sy + (SLOT - 16f) / 2f);
            if (it.getCount() > 1) {
                String n = String.valueOf(it.getCount());
                text(ctx, tr, Fnt.TINY_B, n, sx + SLOT - 2f - width(tr, Fnt.TINY_B, n), sy + SLOT - 5f, argb(a, 0xFFFFFF));
            }
            if (it.isItemBarVisible()) {
                float bw = 14f, bx = sx + (SLOT - bw) / 2f, by = sy + SLOT - 4.5f;
                box(ctx, RR, bx, by, bw, 2f, 1f, argb(0.85f * a, 0x000000));
                box(ctx, RR, bx, by, Math.max(1.5f, bw * it.getItemBarStep() / 13f), 2f, 1f, argb(a, it.getItemBarColor()));
            }
        }

        // fill bar
        float by = GRID_Y + ROWS * SLOT + (ROWS - 1) * GAP + 8f, bw = W - PAD * 2f;
        box(ctx, RR, PAD, by, bw, 4f, 2f, argb(0.45f * a, 0x000000));
        if (filled > 0) box(ctx, RR, PAD, by, Math.max(4f, bw * filled / (COLS * ROWS)), 4f, 2f, argb(a, tint));
    }

    private static void item(DrawContext ctx, ItemStack st, float x, float y) {
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(x, y);
        ctx.drawItem(st, 0, 0);
        ctx.getMatrices().popMatrix();
    }
}
