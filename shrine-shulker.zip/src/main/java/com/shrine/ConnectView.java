package com.shrine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.util.Util;

/** PS5-style "Подключение к миру..." drawn over vanilla's ConnectScreen (see ConnectScreenMixin). */
public final class ConnectView {
    private ConnectView() {}

    private static final Scene SCENE = new Scene();
    static { SCENE.instantBackdrop = true; }   // continues the backdrop of the server screen without a dip
    private static long lastRender;

    public static void render(DrawContext ctx, MinecraftClient mc, int w, int h, int mxReal, int myReal, float delta) {
        render(ctx, mc, w, h, mxReal, myReal, delta, false);
    }

    public static void render(DrawContext ctx, MinecraftClient mc, int w, int h, int mxReal, int myReal, float delta, boolean forceLoading) {
        long now = Util.getMeasuringTimeMs();
        if (SCENE.w != w || SCENE.h != h || now - lastRender > 600) SCENE.init(w, h); // fresh fade-in on each connect
        lastRender = now;

        SCENE.begin(ctx, mxReal, myReal, delta);
        SCENE.stars(ctx, delta);
        float f = SCENE.fade();
        float cx = SCENE.vw / 2f;

        Gfx.centered(ctx, Gfx.GLOW, cx, 226f, 300f, 220f, Gfx.argb(0.22f * f, Gfx.ACCENT));
        if (PsState.favicon != null) {
            Gfx.centered(ctx, PsState.favicon, cx, 226f, 96f, 96f, Gfx.argb(f, 0xFFFFFF));
        } else if (PsState.initials != null) {
            Gfx.textC(ctx, mc.textRenderer, Gfx.Fnt.HUGE, PsState.initials, cx, 226f, Gfx.argb(f, PsState.color));
        } else {
            Gfx.centered(ctx, Gfx.LOGO, cx, 226f, 90f, 90f, Gfx.argb(f, Gfx.ACCENT));
        }

        boolean loading = forceLoading || SCENE.time > 1.8f;
        int dots = (int) ((SCENE.time * 2.2f) % 4);
        String text = (loading ? "Загрузка мира" : "Подключение к миру") + ".".repeat(dots);
        float swap = !loading ? 1f : (forceLoading ? 1f : Math.min(1f, (SCENE.time - 1.8f) / 0.35f));   // quick cross-fade between phases
        float pulse = (0.75f + 0.25f * (float) Math.sin(SCENE.time * 3f)) * swap;
        // fixed-width anchor so the text does not jitter while the dots change
        float x = cx - Gfx.width(mc.textRenderer, Gfx.Fnt.TITLE, "Подключение к миру...") / 2f;
        Gfx.text(ctx, mc.textRenderer, Gfx.Fnt.TITLE, text, x, 307f, Gfx.argb(pulse * f, 0xFF8A8A));
        SCENE.end(ctx);
    }

    /** Draws vanilla's Cancel button as a PS5-style pill (the widget keeps handling the click). */
    public static void drawButton(DrawContext ctx, MinecraftClient mc, ClickableWidget cw) {
        float k = SCENE.k, f = SCENE.fade();
        if (k <= 0f) return;
        float cx = (cw.getX() + cw.getWidth() / 2f) / k, cy = (cw.getY() + cw.getHeight() / 2f) / k;
        float pw = 168f, ph = 40f;
        boolean hov = cw.isHovered();
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        Gfx.box(ctx, Gfx.RR, cx - pw / 2f, cy - ph / 2f, pw, ph, ph / 2f, Gfx.argb((hov ? 0.96f : 0.14f) * f, 0xFFFFFF));
        Gfx.textC(ctx, mc.textRenderer, Gfx.Fnt.UI, cw.getMessage().getString(), cx, cy,
                Gfx.argb(f, hov ? 0x14101A : 0xFFFFFF));
        ctx.getMatrices().popMatrix();
    }
}
