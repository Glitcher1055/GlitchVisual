package com.shrine;

import net.minecraft.util.Identifier;

/** What the connecting screen should show (set when the player presses "Играть"). */
final class PsState {
    private PsState() {}
    static String initials;   // null -> show the Shrine logo instead
    static int color = 0xFFFFFF;
    static Identifier favicon; // real server icon, if the ping returned one
}
