package com.shrine;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * PS5-style home screen. The whole layout is designed on a virtual 540-unit-high canvas and scaled to the
 * real screen height, so it looks identical on phone / PC / any GUI scale (like the reference video).
 */
public final class ShrineMenuScreen extends Screen {

    /** Virtual canvas height. Smaller value = bigger UI, larger value = smaller UI. */
    private static final float REF_H = 540f;

    // ---------- assets ----------
    private static Identifier tex(String n) { return Identifier.of("shrine", "textures/gui/" + n + ".png"); }
    private static final Identifier DISC = tex("disc"), RING = tex("ring"), GLOW = tex("glow"), DOT = tex("dot"),
            BEAM = tex("beam"), LOGO = tex("logo"), I_GEAR = tex("icon_gear"), I_PERSON = tex("icon_person"),
            I_GROUP = tex("icon_group");
    private static final Identifier F_TITLE = Identifier.of("shrine", "title");
    private static final Identifier F_TITLE_BOLD = Identifier.of("shrine", "title_bold");
    private static final Identifier F_LABEL = Identifier.of("shrine", "label");
    private static final Identifier F_SMALL = Identifier.of("shrine", "small");

    private static Text styled(String s, Identifier font) {
        return Text.literal(s).setStyle(Style.EMPTY.withFont(new StyleSpriteSource.Font(font)));
    }

    // ---------- layout (virtual units) ----------
    private static final int ACCENT = 0xFF3A3A;
    private static final float BTN_R = 43f;
    private static final float BTN_GAP = 112f;
    private static final float BTN_CY = 292f;
    private static final float TITLE_Y = 166f;
    private static final int STARS = 190, BOKEH = 16;
    private static final DateTimeFormatter CLOCK_FMT =
            DateTimeFormatter.ofPattern("HH:mm, EEEE", Locale.forLanguageTag("ru-RU"));

    private final Screen parent;
    private final Random rnd = new Random(7L);
    private final List<Star> stars = new ArrayList<>();
    private final List<MenuButton> buttons = new ArrayList<>();
    private long openedAt;
    private Runnable pending;   // action to run after the fade-out
    private long exitAt;
    private float time;
    private float k = 1f;   // real GUI units per virtual unit
    private float vw = 960f; // virtual width

    public ShrineMenuScreen(Screen parent) {
        super(Text.literal("shrine"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        openedAt = Util.getMeasuringTimeMs();
        k = height / REF_H;
        vw = width / k;

        stars.clear();
        for (int i = 0; i < STARS + BOKEH; i++) {
            boolean bokeh = i >= STARS;
            float depth = bokeh ? 0.35f + rnd.nextFloat() * 0.4f : 0.2f + rnd.nextFloat() * 0.8f;
            float size = bokeh ? 26f + rnd.nextFloat() * 34f : 4f + depth * 5f;
            stars.add(new Star(rnd.nextFloat() * vw, rnd.nextFloat() * REF_H, depth, size, rnd.nextFloat() * 6.28f, bokeh));
        }

        buttons.clear();
        buttons.add(new MenuButton("Настройки", I_GEAR, () -> client.setScreen(new OptionsScreen(this, client.options))));
        buttons.add(new MenuButton("Одиночная игра", I_PERSON, () -> client.setScreen(new PsSingleplayerScreen(this))));
        buttons.add(new MenuButton("Сетевая игра", I_GROUP, () -> client.setScreen(new PsMultiplayerScreen(this))));
        float startX = vw / 2f - (buttons.size() - 1) * BTN_GAP / 2f;
        for (int i = 0; i < buttons.size(); i++) buttons.get(i).setCenter(startX + i * BTN_GAP, BTN_CY);
    }

    // ---------- render ----------
    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        time += delta / 20f;
        float fade = Math.min(1f, (Util.getMeasuringTimeMs() - openedAt) / 800f);
        fade = 1f - (1f - fade) * (1f - fade);
        if (pending != null) {
            float out = 1f - (Util.getMeasuringTimeMs() - exitAt) / 280f;
            if (out <= 0f) { Gfx.cover(ctx, width, height); Runnable r = pending; pending = null; r.run(); return; }
            fade *= out;
        }
        float pulse = 0.88f + 0.12f * (float) Math.sin(time * 1.2f);

        // full-screen layers (real coordinates)
        ctx.fillGradient(0, 0, width, height, 0xFF0C0205, 0xFF1E0509);
        blit(ctx, BEAM, 0, 0, width, height, argb(0.80f * pulse * fade, ACCENT));
        blit(ctx, BEAM, 0, 0, width, height, argb(0.22f * pulse * fade, 0xFFFFFF));

        // everything else lives on the virtual canvas
        float mx = mxReal / k, my = myReal / k;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);

        centered(ctx, GLOW, vw / 2f, REF_H / 2f + 20f, vw * 0.9f, REF_H * 0.7f, argb(0.10f * fade, ACCENT));
        drawStars(ctx, mx, my, delta, fade);
        drawTitle(ctx, fade);

        for (MenuButton b : buttons) {
            boolean hov = b.contains(mx, my);
            b.hover += ((hov ? 1f : 0f) - b.hover) * Math.min(1f, delta * 0.28f);
            float h = b.hover;
            float cy = b.cy + (1f - fade) * 24f;
            float d = BTN_R * 2f * (1f + 0.10f * h);

            centered(ctx, GLOW, b.cx, cy, d * 2.1f, d * 2.1f, argb((0.05f + 0.34f * h) * fade, ACCENT));
            centered(ctx, DISC, b.cx, cy, d, d, argb((0.12f + 0.12f * h) * fade, 0xFFFFFF));
            centered(ctx, RING, b.cx, cy, d, d, argb((0.16f + 0.50f * h) * fade, h > 0.5f ? 0xFFFFFF : 0xE6C4C4));
            centered(ctx, b.icon, b.cx, cy, d * 0.46f, d * 0.46f, argb((0.55f + 0.45f * h) * fade, 0xFFFFFF));
            // label is invisible by default; fades in (and rises a little) only while the cursor is on the button
            if (h > 0.02f) {
                drawCentered(ctx, styled(b.label, F_LABEL), b.cx, cy + BTN_R + 16f + 8f * (1f - h),
                        argb(h * fade, 0xFFFFFF));
            }
        }

        String raw = LocalDateTime.now().format(CLOCK_FMT);
        int sp = raw.indexOf(' ');
        String clock = (sp >= 0 && sp + 1 < raw.length())
                ? raw.substring(0, sp + 1) + Character.toUpperCase(raw.charAt(sp + 1)) + raw.substring(sp + 2) : raw;
        Text clockText = styled(clock, F_LABEL);
        ctx.drawText(textRenderer, clockText, Math.round(vw - textRenderer.getWidth(clockText) - 26), 16,
                argb(0.9f * fade, 0xFFFFFF), false);
        drawCentered(ctx, styled("ShrineVisual • " + LocalDateTime.now().getYear(), F_SMALL),
                vw / 2f, REF_H - 30f, argb(0.28f * fade, 0xFFFFFF));

        ctx.getMatrices().popMatrix();
    }

    private void drawStars(DrawContext ctx, float mx, float my, float delta, float fade) {
        float px = (mx - vw / 2f) / vw, py = (my - REF_H / 2f) / REF_H;
        for (Star s : stars) {
            s.y += s.depth * (s.bokeh ? 0.35f : 0.75f) * delta;
            if (s.y > REF_H + s.size) { s.y = -s.size; s.x = rnd.nextFloat() * vw; }
            float tw = 0.4f + 0.6f * Math.abs((float) Math.sin(time * (s.bokeh ? 0.8f : 1.9f) + s.phase));
            float x = s.x - px * 36f * s.depth, y = s.y - py * 20f * s.depth;
            if (s.bokeh) centered(ctx, GLOW, x, y, s.size * 1.6f, s.size * 1.6f, argb(0.10f * tw * fade, ACCENT));
            else centered(ctx, DOT, x, y, s.size, s.size, argb(0.95f * tw * fade, s.depth > 0.8f ? ACCENT : 0xFFFFFF));
        }
    }

    private void drawTitle(DrawContext ctx, float fade) {
        Text prefix = styled("Добро пожаловать в ", F_TITLE);
        Text brand = styled("Shrine!", F_TITLE_BOLD);
        int pw = textRenderer.getWidth(prefix), bw = textRenderer.getWidth(brand);
        float logo = 30f;
        float x = vw / 2f - (pw + logo + 8 + bw) / 2f;
        float y = TITLE_Y - (1f - fade) * 16f;

        ctx.drawText(textRenderer, prefix, Math.round(x), Math.round(y), argb(0.92f * fade, 0xFFFFFF), false);
        centered(ctx, LOGO, x + pw + logo / 2f, y - 2f, logo, logo, argb(fade, ACCENT));
        ctx.drawText(textRenderer, brand, Math.round(x + pw + logo + 8), Math.round(y), argb(fade, ACCENT), false);
        drawCentered(ctx, styled("Во что сегодня играем?", F_LABEL), vw / 2f, y + 36f, argb(0.42f * fade, 0xFFFFFF));
    }

    // ---------- draw helpers ----------
    private static void blit(DrawContext ctx, Identifier id, int x, int y, int w, int h, int color) {
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, id, x, y, 0f, 0f, w, h, 1, 1, 1, 1, color);
    }

    private static void centered(DrawContext ctx, Identifier id, float cx, float cy, float w, float h, int color) {
        blit(ctx, id, Math.round(cx - w / 2f), Math.round(cy - h / 2f), Math.max(1, Math.round(w)), Math.max(1, Math.round(h)), color);
    }

    private void drawCentered(DrawContext ctx, Text t, float cx, float y, int color) {
        ctx.drawText(textRenderer, t, Math.round(cx - textRenderer.getWidth(t) / 2f), Math.round(y), color, false);
    }

    private static int argb(float a, int rgb) {
        int al = Math.round(Math.max(0f, Math.min(1f, a)) * 255f);
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() == 0) {
            double mx = click.x() / k, my = click.y() / k;
            for (MenuButton b : buttons) {
                if (b.contains(mx, my)) {
                    if (pending == null) { pending = b.action; exitAt = Util.getMeasuringTimeMs(); }
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override public boolean shouldPause() { return false; }
    @Override public boolean shouldCloseOnEsc() { return false; }

    // ---------- data ----------
    private static final class MenuButton {
        final String label; final Identifier icon; final Runnable action;
        float cx, cy, hover;
        MenuButton(String label, Identifier icon, Runnable action) { this.label = label; this.icon = icon; this.action = action; }
        void setCenter(float x, float y) { cx = x; cy = y; }
        boolean contains(double mx, double my) {
            double dx = mx - cx, dy = my - cy, r = BTN_R * (1.0 + 0.10 * hover);
            return dx * dx + dy * dy <= r * r;
        }
    }

    private static final class Star {
        float x, y, depth, size, phase; boolean bokeh;
        Star(float x, float y, float depth, float size, float phase, boolean bokeh) {
            this.x = x; this.y = y; this.depth = depth; this.size = size; this.phase = phase; this.bokeh = bokeh;
        }
    }
}
