package com.shrine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.GameMode;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Play with friends: opens the world to LAN and starts the playit.gg agent so friends get a permanent link. */
final class FriendsHost {
    private FriendsHost() {}

    static final String K_ADDR = "friends.address", K_SECRET = "friends.secret", K_AGENT = "friends.agent",
            K_PORT = "friends.port", K_ARGS = "friends.args", K_PIRATES = "friends.pirates";

    private static Process agent;
    private static boolean hosting;
    static String error = "";

    static { Runtime.getRuntime().addShutdownHook(new Thread(FriendsHost::killAgent)); }

    static boolean hosting() { return hosting; }
    static String address() { return ShrineCfg.str(K_ADDR, "").trim(); }
    static boolean pirates() { return ShrineCfg.bool(K_PIRATES, true); }
    static boolean configured() {
        return !address().isEmpty() && !ShrineCfg.str(K_SECRET, "").isBlank() && !ShrineCfg.str(K_AGENT, "").isBlank();
    }

    static void start() {
        error = "";
        MinecraftClient mc = MinecraftClient.getInstance();
        IntegratedServer srv = mc.getServer();
        if (srv == null) { error = "Только в одиночном мире"; return; }
        if (!configured()) { error = "Заполни friends.* в config/shrine.properties"; return; }
        int port = ShrineCfg.integer(K_PORT, 25565);
        File exe = new File(ShrineCfg.str(K_AGENT, ""));
        if (!exe.isFile()) { error = "Не найден файл агента playit"; return; }
        if (srv.isRemote()) {
            if (srv.getServerPort() != port) { error = "Мир уже открыт в LAN на порту " + srv.getServerPort(); return; }
        } else {
            GameMode gm = mc.interactionManager != null ? mc.interactionManager.getCurrentGameMode() : GameMode.SURVIVAL;
            if (!srv.openToLan(gm, false, port)) { error = "Порт " + port + " занят"; return; }
        }
        srv.setOnlineMode(!pirates());
        try {
            List<String> cmd = new ArrayList<>();
            cmd.add(exe.getAbsolutePath());
            for (String a : ShrineCfg.str(K_ARGS, "-s --secret {secret}").trim().split("\\s+"))
                cmd.add(a.replace("{secret}", ShrineCfg.str(K_SECRET, "")));
            killAgent();
            agent = new ProcessBuilder(cmd).directory(exe.getAbsoluteFile().getParentFile())
                    .redirectErrorStream(true).redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
            hosting = true;
        } catch (Exception e) {
            error = "Агент не запустился";
        }
    }

    static void stop() { killAgent(); hosting = false; }

    private static void killAgent() {
        if (agent != null) { agent.destroy(); agent = null; }
    }

    static void setPirates(boolean v) {
        ShrineCfg.setBool(K_PIRATES, v);
        ShrineCfg.save();
        IntegratedServer srv = MinecraftClient.getInstance().getServer();
        if (srv != null) srv.setOnlineMode(!v);
    }

    /** Names of the connected friends (without yourself). */
    static List<String> players() {
        List<String> out = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();
        IntegratedServer srv = mc.getServer();
        if (srv == null || !hosting) return out;
        String me = mc.getSession().getUsername();
        for (ServerPlayerEntity p : srv.getPlayerManager().getPlayerList()) {
            String n = p.getName().getString();
            if (!n.equals(me)) out.add(n);
        }
        return out;
    }
}
