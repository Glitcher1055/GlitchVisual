package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.util.List;

import static com.shrine.Gfx.*;

/** "Играть с друзьями": link, copy, pirate switch, start / stop hosting, connected players. */
final class FriendsScreen extends Screen {
    static final String TITLE = "Играть с друзьями";

    private final Screen parent;
    private final long openedAt = Util.getMeasuringTimeMs();
    private long copiedAt;
    private float k = 1f, vw = 960f;
    private float[] rClose = new float[4], rCopy = new float[4], rToggle = new float[4], rMain = new float[4];

    FriendsScreen(Screen parent) {
        super(Text.literal(TITLE));
        this.parent = parent;
    }

    /** Adds a vanilla button to the pause screen; WorldCreateFx.initPause turns it into a card. */
    static void addPauseButton(Screen screen) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getServer() == null) return;
        Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal(TITLE),
                b -> mc.setScreen(new FriendsScreen(screen))).dimensions(0, 0, 100, 20).build());
    }

    @Override protected void init() { k = height / Scene.REF_H; vw = width / k; }
    @Override public boolean shouldPause() { return false; }
    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { }

    private float alpha() {
        float t = Math.min(1f, (Util.getMeasuringTimeMs() - openedAt) / 200f);
        return 1f - (1f - t) * (1f - t);
    }

    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        float a = alpha();
        ctx.fillGradient(0, 0, width, height, argb(0.55f * a, 0x0C0205), argb(0.78f * a, 0x2A0509));
        float mx = mxReal / k, my = myReal / k;
        boolean on = FriendsHost.hosting();
        List<String> pl = FriendsHost.players();
        int shown = Math.min(pl.size(), 5);

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        float w = 440f, h = 300f + (on && shown > 0 ? shown * 22f + 12f : 0f);
        float x = (vw - w) / 2f, y = (Scene.REF_H - h) / 2f + (1f - a) * 14f;

        box(ctx, RR, x - 1, y - 1, w + 2, h + 2, 27, argb(0.10f * a, 0xFFFFFF));
        box(ctx, RR, x, y, w, h, 26, argb(0.97f * a, 0x1A1116));
        text(ctx, textRenderer, Fnt.UI_B, TITLE, x + 24, y + 33, argb(a, 0xFFFFFF));

        float cx = x + w - 30, cy = y + 33;
        boolean hc = inside(mx, my, cx - 14, cy - 14, 28, 28);
        centered(ctx, DISC, cx, cy, 22, 22, argb((hc ? 1f : 0.88f) * a, 0xFF6B6B));
        textC(ctx, textRenderer, Fnt.TINY_B, "×", cx, cy - 0.5f, argb(a, 0x2A0A0A));
        rClose = new float[]{cx - 14, cy - 14, 28, 28};

        // status
        centered(ctx, DISC, x + 29, y + 72, 10, 10, argb(a, on ? 0x5DE08A : 0x8A8590));
        text(ctx, textRenderer, Fnt.LABEL, on ? "Онлайн · подключено: " + pl.size() : "Не запущено",
                x + 42, y + 72, argb(0.85f * a, on ? 0x9DF0B8 : 0xFFFFFF));

        // address + copy
        String addr = FriendsHost.address();
        float aw = w - 40 - 112;
        box(ctx, RR, x + 20, y + 92, aw, 42, 14, argb(0.09f * a, 0xFFFFFF));
        box(ctx, RR_RING, x + 20, y + 92, aw, 42, 14, argb(0.16f * a, 0xFFFFFF));
        String shownAddr = addr.isEmpty() ? "Укажи friends.address в конфиге" : addr;
        while (shownAddr.length() > 4 && Gfx.width(textRenderer, Fnt.LABEL, shownAddr) > aw - 28)
            shownAddr = shownAddr.substring(0, shownAddr.length() - 2);
        text(ctx, textRenderer, Fnt.LABEL, shownAddr, x + 34, y + 113, argb((addr.isEmpty() ? 0.38f : 1f) * a, 0xFFFFFF));
        rCopy = new float[]{x + w - 20 - 102, y + 92, 102, 42};
        boolean hcp = inside(mx, my, rCopy[0], rCopy[1], rCopy[2], rCopy[3]);
        box(ctx, RR, rCopy[0], rCopy[1], rCopy[2], rCopy[3], 21, argb((hcp ? 1f : 0.92f) * a, 0xFFFFFF));
        boolean copied = Util.getMeasuringTimeMs() - copiedAt < 1500L;
        textC(ctx, textRenderer, Fnt.LABEL, copied ? "Готово" : "Копировать",
                rCopy[0] + rCopy[2] / 2, rCopy[1] + rCopy[3] / 2, argb(a, 0x14101A));

        // pirate switch
        rToggle = new float[]{x + 20, y + 146, w - 40, 52};
        boolean ht = inside(mx, my, rToggle[0], rToggle[1], rToggle[2], rToggle[3]);
        box(ctx, RR, rToggle[0], rToggle[1], rToggle[2], rToggle[3], 16, argb((ht ? 0.16f : 0.09f) * a, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.LABEL, "Пиратские аккаунты", x + 36, y + 165, argb(a, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.SMALL, "Любой по ссылке заходит под своим ником", x + 36, y + 184, argb(0.55f * a, 0xFFFFFF));
        boolean pir = FriendsHost.pirates();
        float sx = x + w - 20 - 16 - 44, sy = y + 146 + 14;
        box(ctx, RR, sx, sy, 44, 24, 12, argb(a, pir ? ACCENT : 0x5A5560));
        centered(ctx, DISC, pir ? sx + 32 : sx + 12, sy + 12, 18, 18, argb(a, 0xFFFFFF));

        // start / stop
        rMain = new float[]{x + 20, y + 214, w - 40, 44};
        boolean hm = inside(mx, my, rMain[0], rMain[1], rMain[2], rMain[3]);
        if (on) {
            box(ctx, RR, rMain[0], rMain[1], rMain[2], rMain[3], 22, argb((hm ? 0.75f : 0.58f) * a, 0xB03A3A));
            box(ctx, RR_RING, rMain[0], rMain[1], rMain[2], rMain[3], 22, argb((hm ? 0.55f : 0.28f) * a, 0xFFFFFF));
            textC(ctx, textRenderer, Fnt.UI_B, "Остановить хостинг", rMain[0] + rMain[2] / 2, rMain[1] + rMain[3] / 2, argb(a, 0xFFB0B0));
        } else {
            if (hm) box(ctx, RR_RING, rMain[0] - 4, rMain[1] - 4, rMain[2] + 8, rMain[3] + 8, 26, argb(0.55f * a, 0xFFFFFF));
            box(ctx, RR, rMain[0], rMain[1], rMain[2], rMain[3], 22, argb(0.97f * a, 0xFFFFFF));
            textC(ctx, textRenderer, Fnt.UI_B, "Запустить хостинг", rMain[0] + rMain[2] / 2, rMain[1] + rMain[3] / 2, argb(a, 0x14101A));
        }

        // connected players
        if (on && shown > 0) {
            for (int i = 0; i < shown; i++) {
                float py = y + 282 + i * 22f;
                centered(ctx, DISC, x + 32, py, 8, 8, argb(a, 0x5DE08A));
                text(ctx, textRenderer, Fnt.LABEL, pl.get(i), x + 46, py, argb(0.9f * a, 0xD6D6FF));
            }
        }

        // error / hint
        float hy = y + h - 24;
        if (!FriendsHost.error.isEmpty()) textC(ctx, textRenderer, Fnt.SMALL, FriendsHost.error, x + w / 2, hy, argb(a, 0xFF7A7A));
        else textC(ctx, textRenderer, Fnt.SMALL, "Друзья заходят: Сетевая игра → Прямое подключение", x + w / 2, hy, argb(0.45f * a, 0xFFFFFF));
        ctx.getMatrices().popMatrix();
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        double mx = click.x() / k, my = click.y() / k;
        if (inside(mx, my, rClose[0], rClose[1], rClose[2], rClose[3])) { close(); return true; }
        if (inside(mx, my, rCopy[0], rCopy[1], rCopy[2], rCopy[3])) {
            if (!FriendsHost.address().isEmpty() && client != null) {
                client.keyboard.setClipboard(FriendsHost.address());
                copiedAt = Util.getMeasuringTimeMs();
            }
            return true;
        }
        if (inside(mx, my, rToggle[0], rToggle[1], rToggle[2], rToggle[3])) { FriendsHost.setPirates(!FriendsHost.pirates()); return true; }
        if (inside(mx, my, rMain[0], rMain[1], rMain[2], rMain[3])) {
            if (FriendsHost.hosting()) FriendsHost.stop(); else FriendsHost.start();
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        return super.keyPressed(input);
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }
}
