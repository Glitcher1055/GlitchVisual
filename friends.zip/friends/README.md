# Play with friends для Shrine

## Установка
1. Скопируй `com/shrine/friends/*` и `com/shrine/mixin/GameMenuFriendsMixin.java` в исходники Shrine.
2. В `shrine.mixins.json` добавь `"GameMenuFriendsMixin"` в массив `client`.
3. Собери мод (Fabric 1.21.11, Yarn).

## playit.gg (один раз)
1. Зарегистрируйся на playit.gg, скачай агент, создай Agent и скопируй его secret.
2. Tunnels -> Add -> Minecraft Java, локальный порт 25565. Скопируй выданный адрес (он постоянный).
3. Первый запуск мода создаст `config/shrine-friends.json`: впиши `publicAddress`, `secret`, `agentPath`.
4. Проверь `agentArgs` командой `<agent> --help`.

## Использование
Паузa (Esc) -> Play with friends -> Start hosting -> Copy -> скинуть другу.
Друг: Multiplayer -> Direct Connection -> вставить адрес.
