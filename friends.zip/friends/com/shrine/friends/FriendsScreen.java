package com.shrine.friends;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

public class FriendsScreen extends Screen {
    private final Screen parent;
    private ButtonWidget main, copy, toggle;

    public FriendsScreen(Screen parent) {
        super(Text.literal("Play with friends"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2, y = height / 2 - 20;
        copy = addDrawableChild(ButtonWidget.builder(Text.literal("Copy"), b ->
                client.keyboard.setClipboard(FriendsHost.address())).dimensions(cx + 70, y, 60, 20).build());
        toggle = addDrawableChild(ButtonWidget.builder(toggleText(), b -> {
            FriendsHost.setAllowNonLicensed(!FriendsCfg.get().allowNonLicensed);
            b.setMessage(toggleText());
        }).dimensions(cx - 130, y + 30, 260, 20).build());
        main = addDrawableChild(ButtonWidget.builder(mainText(), b -> {
            if (FriendsHost.isHosting()) FriendsHost.stop(); else FriendsHost.start();
            b.setMessage(mainText());
        }).dimensions(cx - 130, y + 60, 260, 22).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> client.setScreen(parent))
                .dimensions(cx - 50, height - 30, 100, 20).build());
    }

    private Text toggleText() {
        return Text.literal("Allow non-licensed accounts: " + (FriendsCfg.get().allowNonLicensed ? "ON" : "OFF"));
    }
    private Text mainText() {
        return Text.literal(FriendsHost.isHosting() ? "Stop hosting" : "Start hosting");
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fillGradient(0, 0, width, height, 0xE0120A24, 0xE02A1260);
        int cx = width / 2, y = height / 2 - 20;
        ctx.drawCenteredTextWithShadow(textRenderer, title, cx, y - 50, 0xFFFFFFFF);
        boolean on = FriendsHost.isHosting();
        List<String> pl = FriendsHost.players();
        ctx.drawTextWithShadow(textRenderer, on ? "● Online - " + Math.max(0, pl.size() - 1) + " connected" : "○ Offline",
                cx - 130, y - 25, on ? 0xFF55FF77 : 0xFF999999);
        String addr = FriendsHost.address().isBlank() ? "(set address in config)" : FriendsHost.address();
        ctx.fill(cx - 130, y - 2, cx + 64, y + 22, 0xAA000000);
        ctx.drawTextWithShadow(textRenderer, addr, cx - 124, y + 4, 0xFFFFFFFF);
        int ly = y + 92;
        for (String n : pl) { ctx.drawTextWithShadow(textRenderer, "• " + n, cx - 130, ly, 0xFFD6C6FF); ly += 11; }
        if (!FriendsHost.error().isEmpty())
            ctx.drawCenteredTextWithShadow(textRenderer, FriendsHost.error(), cx, height - 50, 0xFFFF5555);
        ctx.drawCenteredTextWithShadow(textRenderer, "Friends join via Multiplayer > Direct Connection",
                cx, height - 45 + (FriendsHost.error().isEmpty() ? 0 : 12), 0xFF8877AA);
        super.render(ctx, mx, my, delta);
    }

    @Override
    public void close() { client.setScreen(parent); }
}
