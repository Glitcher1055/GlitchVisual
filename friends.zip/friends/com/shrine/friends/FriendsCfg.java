package com.shrine.friends;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Config: config/shrine-friends.json */
public final class FriendsCfg {
    /** Постоянный адрес из панели playit.gg (Tunnels -> Minecraft Java), напр. "abc-123.joinmc.link". */
    public String publicAddress = "";
    /** Secret-ключ агента playit.gg (из панели, раздел Agents). */
    public String secret = "";
    /** Путь к playit-agent (playit-windows-x86_64.exe / playit-linux-amd64). */
    public String agentPath = "";
    /** Аргументы агента. {secret} подставится автоматически. Сверь с версией своего агента: `playit --help`. */
    public String[] agentArgs = {"-s", "--secret", "{secret}"};
    /** Локальный порт, на который в playit направлен туннель. */
    public int port = 25565;
    public boolean allowNonLicensed = true;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("shrine-friends.json");
    private static FriendsCfg inst;

    public static FriendsCfg get() {
        if (inst == null) {
            try {
                inst = Files.exists(FILE) ? GSON.fromJson(Files.readString(FILE), FriendsCfg.class) : new FriendsCfg();
            } catch (Exception e) { inst = new FriendsCfg(); }
            if (inst == null) inst = new FriendsCfg();
            save();
        }
        return inst;
    }

    public static void save() {
        try { Files.writeString(FILE, GSON.toJson(inst)); } catch (Exception ignored) {}
    }
}
