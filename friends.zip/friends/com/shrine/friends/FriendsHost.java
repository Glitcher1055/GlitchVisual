package com.shrine.friends;

import net.minecraft.client.MinecraftClient;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.GameMode;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Хостинг мира: открывает LAN на фиксированном порту + запускает playit-агент. */
public final class FriendsHost {
    private static Process agent;
    private static boolean hosting;
    private static String error = "";

    public static boolean isHosting() { return hosting; }
    public static String error() { return error; }
    public static String address() { return FriendsCfg.get().publicAddress; }

    /** Запускать на клиентском потоке. */
    public static void start() {
        error = "";
        MinecraftClient mc = MinecraftClient.getInstance();
        IntegratedServer srv = mc.getServer();
        FriendsCfg cfg = FriendsCfg.get();
        if (srv == null) { error = "Open a singleplayer world first"; return; }
        if (cfg.publicAddress.isBlank() || cfg.agentPath.isBlank() || cfg.secret.isBlank()) {
            error = "Fill config/shrine-friends.json (address, secret, agentPath)";
            return;
        }
        // isRemote() == true, если мир уже открыт в LAN (напр. ваниль «Open to LAN»)
        if (!srv.isRemote() && !srv.openToLan(GameMode.SURVIVAL, false, cfg.port)) {
            error = "Port " + cfg.port + " is busy";
            return;
        }
        srv.setOnlineMode(!cfg.allowNonLicensed);
        try {
            List<String> cmd = new ArrayList<>();
            cmd.add(cfg.agentPath);
            for (String a : cfg.agentArgs) cmd.add(a.replace("{secret}", cfg.secret));
            agent = new ProcessBuilder(cmd).directory(new File(cfg.agentPath).getParentFile())
                    .redirectErrorStream(true).redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
            hosting = true;
        } catch (Exception e) {
            error = "Agent failed: " + e.getMessage();
        }
    }

    public static void stop() {
        if (agent != null) { agent.destroy(); agent = null; }
        hosting = false;
        // Порт LAN закрывается вместе с миром; ваниль не даёт закрыть его на лету.
    }

    public static void setAllowNonLicensed(boolean v) {
        FriendsCfg.get().allowNonLicensed = v;
        FriendsCfg.save();
        IntegratedServer srv = MinecraftClient.getInstance().getServer();
        if (srv != null) srv.setOnlineMode(!v);
    }

    public static List<String> players() {
        List<String> out = new ArrayList<>();
        IntegratedServer srv = MinecraftClient.getInstance().getServer();
        if (srv != null) for (ServerPlayerEntity p : srv.getPlayerManager().getPlayerList())
            out.add(p.getName().getString());
        return out;
    }
}
