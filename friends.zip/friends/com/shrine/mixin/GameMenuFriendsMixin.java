package com.shrine.mixin;

import com.shrine.friends.FriendsScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Добавляет кнопку «Play with friends» в меню паузы. */
@Mixin(GameMenuScreen.class)
public abstract class GameMenuFriendsMixin extends Screen {
    protected GameMenuFriendsMixin(Text t) { super(t); }

    @Inject(method = "init", at = @At("TAIL"))
    private void shrine$friends(CallbackInfo ci) {
        if (client == null || client.getServer() == null) return; // только в одиночном мире
        addDrawableChild(ButtonWidget.builder(Text.literal("Play with friends"),
                b -> client.setScreen(new FriendsScreen(this)))
                .dimensions(width / 2 - 102, height / 4 + 8 + 24 * 7, 204, 20).build());
    }
}
